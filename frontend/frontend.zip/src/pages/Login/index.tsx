// ============================================================
// Login — autentica via servico_autenticacao externo
// ============================================================
import { useState, type FormEvent } from 'react'
import { useNavigate }              from 'react-router-dom'
import { useAuth }                  from '@/context/AuthContext'
import { getUsuarioMe }             from '@/api/endpoints'
import { apiClient }                from '@/api/client'
import styles                       from './Login.module.css'

const AUTH_URL = import.meta.env.VITE_AUTH_URL as string | undefined

export default function Login() {
  const navigate = useNavigate()
  const { login } = useAuth()

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading,  setLoading]  = useState(false)
  const [error,    setError]    = useState<string | null>(null)

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!username || !password) return
    setLoading(true)
    setError(null)

    try {
      let token: string

      if (AUTH_URL) {
        // Produção: autentica contra o servico_autenticacao real
        const res = await fetch(`${AUTH_URL}/login`, {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({ username, password }),
        })
        if (!res.ok) throw new Error('Credenciais inválidas')
        const data = await res.json() as { token?: string; access_token?: string }
        token = data.token ?? data.access_token ?? ''
        if (!token) throw new Error('Token não retornado pelo serviço de autenticação')
      } else {
        // Dev local: usa o campo "senha" como token diretamente
        // (útil para testar com um JWT gerado manualmente)
        token = password
      }

      // Injeta token temporariamente para buscar o perfil
      apiClient.defaults.headers.common['Authorization'] = token
      const usuario = await getUsuarioMe()
      login(token, usuario)
      navigate('/', { replace: true })
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Erro ao autenticar'
      setError(msg)
      delete apiClient.defaults.headers.common['Authorization']
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={styles.root}>
      {/* Grade de fundo decorativa */}
      <div className={styles.grid} aria-hidden="true" />

      <div className={styles.card}>
        {/* Logo / título */}
        <div className={styles.header}>
          <span className={styles.logoMark}>CP</span>
          <div>
            <h1 className={styles.title}>CapacidadeProdutiva</h1>
            <p className={styles.subtitle}>Sistema de Gestão Operacional</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className={styles.form} noValidate>
          <div className={styles.field}>
            <label htmlFor="username" className={styles.label}>
              Usuário
            </label>
            <input
              id="username"
              type="text"
              className={styles.input}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              autoFocus
              disabled={loading}
              placeholder="login"
            />
          </div>

          <div className={styles.field}>
            <label htmlFor="password" className={styles.label}>
              Senha
            </label>
            <input
              id="password"
              type="password"
              className={styles.input}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              disabled={loading}
              placeholder="••••••••"
            />
          </div>

          {error && (
            <div className={styles.errorBox} role="alert">
              <span className={styles.errorIcon}>⚠</span>
              {error}
            </div>
          )}

          <button
            type="submit"
            className={styles.btn}
            disabled={loading || !username || !password}
          >
            {loading ? (
              <span className={styles.spinner} aria-hidden="true" />
            ) : null}
            {loading ? 'Autenticando…' : 'Entrar'}
          </button>
        </form>

        <p className={styles.footer}>
          Autenticação via serviço centralizado de identidade
        </p>
      </div>
    </div>
  )
}
